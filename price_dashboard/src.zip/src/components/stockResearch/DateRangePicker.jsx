import React, { useState } from 'react';
import StockSelector from './StockSelector';
import DateRangePicker from './DateRangePicker';
import SubmitButton from './SubmitButton';
import ChartDisplay from './ChartDisplay';
import ValidationModal from './ValidationModal';
import LoadingSpinner from './LoadingSpinner';
import { fetchEquityData } from '../../utils/fetchEquityData';

import { useDispatch, useSelector } from 'react-redux';
import {
  setChartData
} from '../../redux/stockResearchSlice';

function Dashboard() {
  const dispatch = useDispatch();
  const { selectedTickers, dateRange, chartData } = useSelector(
    (state) => state.stockResearch
  );

  const [modalMessage, setModalMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const validateInputs = (tickers, dateRange) => {
    if (!tickers || tickers.length === 0) {
      return {
        isValid: false,
        message: 'Please select at least one stock ticker.',
      };
    }

    if (!dateRange.start || !dateRange.end) {
      return {
        isValid: false,
        message: 'Please select both a start and end date.',
      };
    }

    if (dateRange.start > dateRange.end) {
      return {
        isValid: false,
        message: 'Start date cannot be after end date.',
      };
    }

    return { isValid: true };
  };

  const handleSubmit = async () => {
    const validation = validateInputs(selectedTickers, dateRange);
    if (!validation.isValid) {
      setModalMessage(validation.message);
      return;
    }

    setLoading(true);
    try {
      const data = await fetchEquityData(selectedTickers, dateRange);
      dispatch(setChartData(data));
    } catch (error) {
      console.error('Error fetching data:', error);
      setModalMessage('Failed to fetch data from API. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="dashboard">
      <StockSelector />
      <DateRangePicker />
      <SubmitButton onClick={handleSubmit} />
      <ChartDisplay data={chartData} />
      {loading && <LoadingSpinner />}
      <ValidationModal message={modalMessage} onClose={() => setModalMessage('')} />
    </div>
  );
}

export default Dashboard;
