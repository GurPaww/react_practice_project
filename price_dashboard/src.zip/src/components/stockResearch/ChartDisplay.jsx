import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  TimeScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import 'chartjs-adapter-date-fns';

ChartJS.register(LineElement, TimeScale, LinearScale, PointElement, Tooltip, Legend, Filler);

// Helper: group by ticker
const groupByTicker = (data) => {
  return data.reduce((acc, item) => {
    if (!acc[item.ticker]) acc[item.ticker] = [];
    acc[item.ticker].push(item);
    return acc;
  }, {});
};

const getColor = (index) => {
  const colors = [
    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
    '#858796', '#fd7e14', '#20c997', '#6f42c1', '#0d6efd'
  ];
  return colors[index % colors.length];
};

function ChartDisplay({ data }) {
  if (data.length === 0) return <div>No data to display.</div>;

  const grouped = groupByTicker(data);

  const datasets = Object.entries(grouped).map(([ticker, tickerData], index) => ({
    label: ticker,
    data: tickerData.map(d => ({ x: d.date, y: d.close })),
    borderColor: getColor(index),
    backgroundColor: getColor(index) + '33', // slight fill (33 = ~20% opacity)
    tension: 0.3,
    fill: false,
  }));

  const chartData = {
    datasets,
  };

  const options = {
    responsive: true,
    interaction: {
      mode: 'nearest',
      intersect: false
    },
    scales: {
      x: {
        type: 'time',
        time: {
          unit: 'day',
        },
        title: {
          display: true,
          text: 'Date',
        },
      },
      y: {
        beginAtZero: false,
        title: {
          display: true,
          text: 'Close Price ($)',
        },
      },
    },
    plugins: {
      legend: {
        display: true,
        position: 'bottom',
      },
      tooltip: {
        mode: 'index',
        intersect: false,
      }
    },
  };

  return (
    <div className="chart-container">
      <Line data={chartData} options={options} />
    </div>
  );
};

export default ChartDisplay;
