import React from 'react';

function SubmitButton({ onClick }) {
    return (
    <div className="form-group">
        <button onClick={onClick}>Submit</button>
    </div>
    )
};

export default SubmitButton;
