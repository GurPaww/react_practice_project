import React, { useState } from 'react';
import StockSelector from './StockSelector';
import DateRangePicker from './DateRangePicker';
import SubmitButton from './SubmitButton';
import ChartDisplay from './ChartDisplay';
// import dummyData from '../data/dummy.json';
import ValidationModal from './ValidationModal';
import LoadingSpinner from './LoadingSpinner';
import { fetchEquityData } from '../../utils/fetchEquityData';

function Dashboard() {
  const [selectedTickers, setSelectedTickers] = useState([]);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [chartData, setChartData] = useState([]);
  const [modalMessage, setModalMessage] = useState('');
  const [loading, setLoading] = useState(false);

  // validation function to check pre-requisite
  const validateInputs = (tickers, dateRange) => {
    if (!tickers || tickers.length === 0) {
      return { isValid: false, message: "Please select at least one stock ticker." };
    }
  
    if (!dateRange.start || !dateRange.end) {
      return { isValid: false, message: "Please select both a start and end date." };
    }
  
    if (dateRange.start > dateRange.end) {
      return { isValid: false, message: "Start date cannot be after end date." };
    }
  
    return { isValid: true };
  };
  
  const handleSubmit = async () => {
    const validation = validateInputs(selectedTickers, dateRange);
  
    if (!validation.isValid) {
      setModalMessage(validation.message);
      return;
    }
  
    setLoading(true);
  
    try {
        const data = await fetchEquityData(selectedTickers, dateRange);
        setChartData(data);
      } catch (error) {
        console.error('Error fetching data:', error);
        setModalMessage('Failed to fetch data from API. Please try again later.');
      } finally {
        setLoading(false);
      }
  };
  

  return (
    <div className="dashboard">
      <StockSelector onChange={setSelectedTickers} />
      <DateRangePicker onChange={setDateRange} />
      <SubmitButton onClick={handleSubmit} />
      <ChartDisplay data={chartData} />
      <ValidationModal message={modalMessage} onClose={() => setModalMessage('')} />
      {loading && <LoadingSpinner />}
<ValidationModal message={modalMessage} onClose={() => setModalMessage('')} />

    </div>
  );
};

export default Dashboard;
