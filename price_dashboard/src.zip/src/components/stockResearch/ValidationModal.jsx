import React from 'react';
import './ValidationModal.css';

function ValidationModal({ message, onClose }) {
  if (!message) return null;

  return (
    <div className="modal-backdrop">
      <div className="modal-content">
        <p>{message}</p>
        <button onClick={onClose}>OK</button>
      </div>
    </div>
  );
};

export default ValidationModal;
