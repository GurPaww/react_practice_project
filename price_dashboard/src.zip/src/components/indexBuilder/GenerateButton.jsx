import React from 'react';

function GenerateButton({ onClick }) {
  return (
    <button className="submit-btn" onClick={onClick}>
      Generate Index
    </button>
  );
}

export default GenerateButton;
