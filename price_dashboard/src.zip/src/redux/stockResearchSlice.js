import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  selectedTickers: [],
  dateRange: { start: '', end: '' },
  chartData: [],
};

const stockResearchSlice = createSlice({
  name: 'stockResearch',
  initialState,
  reducers: {
    setSelectedTickers: (state, action) => {
      state.selectedTickers = action.payload;
    },
    setDateRange: (state, action) => {
      state.dateRange = action.payload;
    },
    setChartData: (state, action) => {
      state.chartData = action.payload;
    },
  },
});

export const {
  setSelectedTickers,
  setDateRange,
  setChartData,
} = stockResearchSlice.actions;

export default stockResearchSlice.reducer;
