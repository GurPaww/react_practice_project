import { configureStore } from '@reduxjs/toolkit';
import stockResearchReducer from './stockResearchSlice';
import indexBuilderReducer from './indexBuilderSlice';

const store = configureStore({
  reducer: {
    stockResearch: stockResearchReducer,
    indexBuilder: indexBuilderReducer,
  },
});

export default store;
