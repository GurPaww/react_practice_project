import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  tickers: [{ symbol: '', weight: '' }],
  rebalanceFreq: 'monthly',
};

const indexBuilderSlice = createSlice({
  name: 'indexBuilder',
  initialState,
  reducers: {
    setTickers: (state, action) => {
      state.tickers = action.payload;
    },
    setRebalanceFreq: (state, action) => {
      state.rebalanceFreq = action.payload;
    },
  },
});

export const {
  setTickers,
  setRebalanceFreq,
} = indexBuilderSlice.actions;

export default indexBuilderSlice.reducer;
