import React, { useState } from 'react';
import TickerInputList from '../components/indexBuilder/TickerInputList';
import RebalanceSelector from '../components/indexBuilder/RebalanceSelector';
import GenerateButton from '../components/indexBuilder/GenerateButton';

function IndexBuilder() {
  const [tickers, setTickers] = useState([{ symbol: '', weight: '' }]);
  const [rebalanceFreq, setRebalanceFreq] = useState('monthly');

  const handleTickerChange = (index, field, value) => {
    const newTickers = [...tickers];
    newTickers[index][field] = value;
    setTickers(newTickers);
  };

  const addTicker = () => setTickers([...tickers, { symbol: '', weight: '' }]);

  const removeTicker = (index) =>
    setTickers(tickers.filter((_, i) => i !== index));

  const handleSubmit = () => {
    console.log({ tickers, rebalanceFreq });
    // TODO: validation, weight should add up to 100%.

    // TODO: API call. API still working on by collegue, fill with dummy data now.
  };

  return (
    <div className="page">
      <h2>Create Your Custom Index</h2>
      <div className="index-form">
        <TickerInputList
          tickers={tickers}
          onChange={handleTickerChange}
          onAdd={addTicker}
          onRemove={removeTicker}
        />
        <RebalanceSelector
          frequency={rebalanceFreq}
          onChange={setRebalanceFreq}
        />
        <GenerateButton onClick={handleSubmit} />
      </div>
    </div>
  );
}

export default IndexBuilder;
